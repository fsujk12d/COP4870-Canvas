﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Janvas1.Models
{
    public class Module
    {
        public string? Name { get; set; }
        public string? Description { get; set; }
        public IList<ModuleItem>? ModContent { get; set; }

        public Module() {       //Default Constructor
            ModContent = new List<ModuleItem>();
        }
    }
}
