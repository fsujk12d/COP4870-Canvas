﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Janvas1.Models
{
    public class Person
    {
        public string? Name { get; set; }
        public string? Classification { get; set; }
        public string? Id { get; set; }
        public decimal Grades { get; set; }

        public Person()     //Default Constructor
        {

        }
    }
}
