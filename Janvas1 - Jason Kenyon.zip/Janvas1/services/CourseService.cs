﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Janvas1.Models;

namespace Janvas1.services
{
    public class CourseService
    {
        public IList<Course> courseList;
        private static CourseService instance;
        private static object l = new object();
        private string? query;
        public static CourseService Current
        {
            get
            {
                lock (l)
                {
                    if (instance == null)
                    {
                        instance = new CourseService();
                    }
                }
                return instance;
            }
        }

        public IEnumerable<Course> Courses
        {
            get {
                return courseList.Where(
                    c => c.Name.Contains(query ?? string.Empty, StringComparison.CurrentCultureIgnoreCase)
                        || c.Code.Contains(query ?? string.Empty, StringComparison.CurrentCultureIgnoreCase)
                        || c.Description.Contains(query ?? string.Empty, StringComparison.CurrentCultureIgnoreCase));
            }
        }

        public IEnumerable<Course> Search(string query)
        {
            this.query = query;
            return Courses;
        }

        public void Add (Course co)
        {
            courseList.Add(co);
        }

        private CourseService()
        {
            courseList = new List<Course>();
        }
    }
}
