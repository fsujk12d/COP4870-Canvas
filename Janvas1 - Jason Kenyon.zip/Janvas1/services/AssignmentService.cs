﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Janvas1.Models;

namespace Janvas1.services
{
    public class AssignmentService
    {
        public IList<Assignment> assnList;
        private static AssignmentService instance;
        private static object l = new object();
        private string? query;
        public static AssignmentService Current
        {
            get
            {
                lock (l)
                {
                    if (instance == null)
                    {
                        instance = new AssignmentService();
                    }
                }
                return instance;
            }
        }

        public IEnumerable<Assignment> Assignments
        {
            get
            {
                return assnList.Where(
                    c => c.Name.Contains(query ?? string.Empty, StringComparison.CurrentCultureIgnoreCase)
                        || c.Description.Contains(query ?? string.Empty, StringComparison.CurrentCultureIgnoreCase));
            }
        }

        public IEnumerable<Assignment> Search(string query)
        {
            this.query = query;
            return Assignments;
        }

        public void Add (Assignment assn)
        {
            assnList.Add(assn);
        }

        private AssignmentService()
        {
            assnList = new List<Assignment>();
        }
    }
}
