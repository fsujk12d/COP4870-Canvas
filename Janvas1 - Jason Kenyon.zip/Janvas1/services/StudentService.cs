﻿using Janvas1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Janvas1.services
{
    public class StudentService
    {
        public IList<Person> students;
        private static StudentService instance;
        private static object l = new object();
        private string query;
        public static StudentService Current
        {
            get
            {
                lock (l)
                {
                    if (instance == null)
                    {
                        instance = new StudentService();
                    }
                }
                return instance;
            }
        }

        public IEnumerable<Person> Students
        {
            get
            {
                return students.Where(
                    c =>
                        c.Name.Contains(query ?? string.Empty, StringComparison.CurrentCultureIgnoreCase)
                        || c.Classification.Contains(query ?? string.Empty, StringComparison.CurrentCultureIgnoreCase)
                        || c.Id.Contains(query ?? string.Empty, StringComparison.CurrentCultureIgnoreCase));
            }
        }

        public IEnumerable<Person> Search(string query)
        {
            this.query = query;
            return Students;
        }

        public void Add(Person stu)
        {
             students.Add(stu);
        }
        private StudentService() {
            students = new List<Person>();
        }
    }
}
