﻿using System;
using System.Security.Cryptography.X509Certificates;
using Janvas1.Models;
using Janvas1.services;

/* COP4870 Assignment 1
 *  Name: Jason Kenyon
 *  FSUID: jk12d    CS Account: kenyon
 *  Description: This is the Console Version of the semester-long project to build our own version of Canvas. Mine is called Janvas. There are a few minor issues 
 *  and features to be added as the semester goes along. Full documentation will be added in a later version.
 */

namespace Janvas1
{
    internal class Program
    { 
        static void Main(string[] args)
        {
            var studentService = StudentService.Current;
            var courseService = CourseService.Current;
            var assignmentService = AssignmentService.Current;

            Console.WriteLine("Welcome to Janvas\n");
            PrintMenu();

            Console.WriteLine("What would you like to do?");
            string? choice = Console.ReadLine();
            while (choice != "69")
            {
                switch (choice)
                {
                    //create course
                    case "1":   
                        AddCourse();
                        break;
                    //create student
                    case "2":   
                        AddStudent();
                        break;
                    //add student to course
                    case "3":   
                        if (PrintStudents(studentService))
                        {
                            Console.WriteLine("Which student will be added? (Select the index) ");
                            string? studentChoice = Console.ReadLine();
                            int stuChoiceInt = int.Parse(studentChoice ?? "0");
                            if (PrintCourses(courseService))
                            {
                                Console.WriteLine("Which course? (Select the Index)");
                                string? courseChoice = Console.ReadLine();
                                int courseChoiceInt = int.Parse(courseChoice ?? "0");
                                courseService.courseList[courseChoiceInt].Roster.Add(studentService.students[stuChoiceInt]);
                            }
                        }
                        break;
                    //remove a student
                    case "4":   
                        if (PrintCourses(courseService))
                        {
                            Console.WriteLine("Which Course? (Select the Index)");
                            string? courseChoice = Console.ReadLine();
                            int courseChoiceInt = int.Parse(courseChoice ?? "0");
                            Course tempCourse = courseService.courseList[courseChoiceInt];
                          
                            if (PrintCourseStudents(tempCourse))
                            {
                                Console.WriteLine("Which Student? (Select the Index)");
                                string? studentChoice = Console.ReadLine();
                                int stuChoiceInt = int.Parse (studentChoice ?? "0");
                                Person tempstu = tempCourse.Roster[courseChoiceInt];
                                tempCourse.Roster.Remove(tempstu);
                            }
                        }
                        break;
                    //list all courses
                    case "5":   
                        PrintCourses(courseService);
                        break;
                    //search for course
                    case "6":   
                        Console.WriteLine("Enter a course name, description, or code: ");
                        string? query = Console.ReadLine();
                        var courseResults = courseService.Search(query);
                        foreach (Course c in courseResults)
                        {
                            Console.WriteLine($"{c.Name} ({c.Code}): {c.Description}");
                        }
                        break;
                    //list all students
                    case "7":   
                        PrintStudents(studentService);
                        break;
                    //search for a student
                    case "8":   
                        Console.WriteLine("Enter a student name or classification: ");
                        query = Console.ReadLine();
                        var studentResults = studentService.Search(query);
                        foreach (Person s in studentResults)
                        {
                            Console.WriteLine($"{s.Name} ({s.Id}), {s.Classification}, {s.Grades} GPA");
                        }
                        break;
                    //list all courses a student is taking
                    case "9":   
                        if (PrintStudents(studentService))
                        {
                            Console.WriteLine("Which student? (Select the index) ");
                            string? studentChoice = Console.ReadLine();
                            int stuChoiceInt = int.Parse(studentChoice ?? "0");
                            Person temp = studentService.students[stuChoiceInt];
                            IList<Course> tempCourseList = new List<Course>();
                            foreach (Course c in courseService.courseList)
                            {
                                if (c.Roster.Contains(temp))
                                {
                                    tempCourseList.Add(c);
                                }
                            }
                            foreach (Course c in tempCourseList)
                            {
                                Console.WriteLine($"{c.Name} ({c.Code})");
                            }
                        }
                        break;
                    //update a course
                    case "10":
                        if (PrintCourses(courseService))
                        {
                            Console.WriteLine("Which course to update? (Select the index)");
                            string? courseChoice = Console.ReadLine();
                            int courseChoiceInt = int.Parse(courseChoice ?? "0");
                            
                            Console.WriteLine("Are you updating the course name? (Y/N)");
                            string? yesno = Console.ReadLine();
                            if (yesno == "Y" || yesno == "y")
                            {
                                Console.WriteLine("Enter new course name:");
                                string? newname = Console.ReadLine();
                                courseService.courseList[courseChoiceInt].Name = newname;
                            }

                            Console.WriteLine("Are you updating the course code? (Y/N)");
                            yesno = Console.ReadLine();
                            if (yesno == "Y" || yesno == "y")
                            {
                                Console.WriteLine("Enter new course code:");
                                string? newcode = Console.ReadLine();
                                courseService.courseList[courseChoiceInt].Code = newcode;
                            }

                            Console.WriteLine("Are you updating the course description? (Y/N)");
                            yesno = Console.ReadLine();
                            if (yesno == "Y" || yesno == "y")
                            {
                                Console.WriteLine("Enter new course description:");
                                string? newdesc = Console.ReadLine();
                                courseService.courseList[courseChoiceInt].Description = newdesc;
                            }

                        }
                        break;
                    //update a student
                    case "11":
                        if (PrintStudents(studentService))
                        {
                            Console.WriteLine("Which student to update? (select the index)");
                            string? stuChoice = Console.ReadLine();
                            int stuChoiceInt = int.Parse(stuChoice ?? "0");

                            Console.WriteLine("Are you updating the student's name? (Y/N)");
                            string? yesno = Console.ReadLine();
                            if (yesno == "Y" || yesno == "y")
                            {
                                Console.WriteLine("Enter new student name:");
                                string? newname = Console.ReadLine();
                                studentService.students[stuChoiceInt].Name = newname;
                            }

                            Console.WriteLine("Are you updating the student's ID? (Y/N)");
                            yesno = Console.ReadLine();
                            if (yesno == "Y" || yesno == "y")
                            {
                                Console.WriteLine("Enter new student ID:");
                                string? newid = Console.ReadLine();
                                studentService.students[stuChoiceInt].Id = newid;
                            }

                            Console.WriteLine("Are you updating the student's classification? (Y/N)");
                            yesno = Console.ReadLine();
                            if (yesno == "Y" || yesno == "y")
                            {
                                Console.WriteLine("Enter new student classification:");
                                string? newclass = Console.ReadLine();
                                studentService.students[stuChoiceInt].Classification = newclass;
                            }

                            Console.WriteLine("Are you updating the student's GPA? (Y/N)");
                            yesno = Console.ReadLine();
                            if (yesno == "Y" || yesno == "y")
                            {
                                Console.WriteLine("Enter new student GPA:");
                                string? newgpa = Console.ReadLine();
                                decimal _newgpa = decimal.Parse(newgpa);
                                studentService.students[stuChoiceInt].Grades = _newgpa;
                            }
                        }
                        break;
                    //create assignment
                    case "12":
                        AddAssignment();
                        break;

                    //list all assignments
                    case "13":
                        if (PrintAssignments(assignmentService))
                        {

                        }
                        break;

                    //add assignment to a course
                    case "14":
                        if (PrintCourses(courseService))
                        {
                            Console.WriteLine("Which course will receive the assignment? (select the index)");
                            string? courseChoiceStr = Console.ReadLine();
                            int courseChoiceInt = int.Parse(courseChoiceStr ?? "0");

                            if (PrintAssignments(assignmentService))
                            {
                                Console.WriteLine("Which assignment will be added?");
                                string? assnChoiceStr = Console.ReadLine();
                                int assnChoiceInt = int.Parse(assnChoiceStr ?? "0");

                                courseService.courseList[courseChoiceInt].Assns.Add(assignmentService.assnList[assnChoiceInt]);
                            }
                        }
                        break;
                    //print the menu again
                    case "99":
                        PrintMenu();
                        break;
                    
                    //print course roster
                    case "33":
                        if (PrintCourses(courseService))
                        {
                            Console.WriteLine("Which course?");
                            string? input = Console.ReadLine();
                            int inputInt = int.Parse(input);
                            Console.WriteLine(courseService.courseList[inputInt].Roster[0].Name);
                        }
                        break;

                    default:    //dummy
                        
                        break;

                }
                Console.WriteLine("What's next? ");
                choice = Console.ReadLine();
            }
            Console.WriteLine("Jank You");

        }

        public static void PrintMenu()
        {
            Console.WriteLine("--- MENU ---\n");
            Console.WriteLine("1. Create a course");
            Console.WriteLine("2. Create a student");
            Console.WriteLine("3. Add a student to a course");
            Console.WriteLine("4. Remove a student from a course");
            Console.WriteLine("5. List all courses");
            Console.WriteLine("6. Search for a course");
            Console.WriteLine("7. List all students");
            Console.WriteLine("8. Search for a student");
            Console.WriteLine("9. List all courses a student is taking");
            Console.WriteLine("10. Update a course");
            Console.WriteLine("11. Update a student");
            Console.WriteLine("12. Create an assignment");
            Console.WriteLine("13. List all assignments");
            Console.WriteLine("14. Add an assignment to a course");
            Console.WriteLine("99. Print menu again");
            Console.WriteLine("69. Exit Janvas");
        }

        public static bool PrintStudents(StudentService stu)
        {
            int count = 0;
            if (stu.Students != null)
            {
                foreach (Person poo in stu.Students)
                {
                    Console.WriteLine($"{count}) {poo.Name} - {poo.Id} - {poo.Classification} - {poo.Grades}");
                    count++;
                }
                return true;
            }
            else
            {
                Console.WriteLine("No students to print.");
                return false;
            }
        }

        public static bool PrintCourseStudents(Course course)
        {
            if (course.Roster != null)
            {
                foreach (Person stu in course.Roster)
                {
                    Console.WriteLine($"{course.Roster.IndexOf(stu)}) {stu.Name} - {stu.Classification}");
                }
                return true;
            }
            else {
                Console.WriteLine("No students to remove");
                return false;
            }
        }

        public static bool PrintCourses(CourseService cou)
        {
            int count = 0;
            if (cou.courseList != null)
            {
                foreach (Course poo in cou.Courses)
                {
                    Console.WriteLine($"{count}) {poo.Name} - {poo.Code} - {poo.Description}");
                    count++;
                }
                return true;
            }
            else
            {
                Console.WriteLine("No courses to print.");
                return false;
            }
        }

        public static bool PrintAssignments(AssignmentService Asn)
        {
            int count = 0;
            if (Asn.assnList != null)
            {
                foreach (Assignment a in Asn.assnList)
                {
                    Console.WriteLine($"{count}) {a.Name} - {a.TotalAvailablePoints} - {a.Date} - {a.Description}");
                    count++;
                }
                return true;
            } else
            {
                Console.WriteLine("No assignments to print.");
                return false;
            }

        }
        
        static void AddStudent()
        {
            Console.WriteLine("Name: ");
            var name = Console.ReadLine();

            Console.WriteLine("ID: ");
            var id = Console.ReadLine();

            Console.WriteLine("Classification: ");
            var classification = Console.ReadLine();

            Console.WriteLine("GPA: ");
            var gpastr = Console.ReadLine();
            decimal gpadbl = decimal.Parse(gpastr ?? "0");

            Person theStudent;
            theStudent = new Person { Name = name, Id = id, Classification = classification, Grades = gpadbl };

            StudentService.Current.Add(theStudent);
        }
       
        static void AddCourse()
        {
            Console.WriteLine("Course Name:");
            var name = Console.ReadLine();

            Console.WriteLine("Description:");
            var description = Console.ReadLine();

            Console.WriteLine("Code:");
            var code = Console.ReadLine();

            Course theCourse = new Course { Name = name, Code = code, Description = description };

            CourseService.Current.courseList.Add(theCourse);
        }

        static void AddAssignment()
        {
            Console.WriteLine("Enter assignment name:");
            string? name = Console.ReadLine();

            Console.WriteLine("Enter assignment description:");
            string? description = Console.ReadLine();

            Console.WriteLine("Enter total points:");
            string? pointsstr = Console.ReadLine();
            int points = int.Parse(pointsstr ?? "0");

            Console.WriteLine("Enter date assigned:");
            string? datestr = Console.ReadLine();
            DateOnly date = DateOnly.Parse(datestr ?? "0");

            Assignment theAssn = new Assignment { Name = name, Description = description, TotalAvailablePoints = points, Date = date };

            AssignmentService.Current.Add(theAssn);

            

        }

    }
}
